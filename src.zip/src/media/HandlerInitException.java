package media;

/**
 * Thrown when a specific content handler (Player or Viewer) fails to load correctly.
 */
public class HandlerInitException extends Exception {
    public HandlerInitException() {}
    public HandlerInitException(String msg) {
        super(msg);
    }
}
