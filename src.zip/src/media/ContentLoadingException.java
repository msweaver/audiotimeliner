package media;

import util.ChainableException;

/**
 * Thrown when errors occur in content rendering and retrieval.
 */
public class ContentLoadingException extends ChainableException {

    public ContentLoadingException(String msg) {
        super(msg);
    }

    public ContentLoadingException(String msg, Exception chainedException) {
        super(msg, chainedException);
    }
}