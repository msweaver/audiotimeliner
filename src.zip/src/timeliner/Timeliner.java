package timeliner;

import ui.timeliner.*;
import ui.common.*;
import util.*;
import org.apache.log4j.PropertyConfigurator;
import util.logging.*;
import javafx.application.Application;
import javafx.stage.*;


/**
 * Title:        Timeliner
 * Copyright:    Copyright (c) 2004
 * Company:      Indiana University
 * @author Brent Yorgason
 * @version 1.0
 */

public class Timeliner extends Application {

  public static final String DEFAULT_LOG4J_CONF = AppEnv.getAppDir() + "conf/client/timeliner_console.lcf";

  public Timeliner() {

  }

  public static void main(String[] args) {
	  launch(args);		    
  }
  
   public void start(Stage stage) throws Exception {
	    if (!AppEnv.isGUISupported()){
	        System.err.println("Audio Timeliner currently only supports Windows and Mac OS X");
	        System.exit(1);
	    }
	    // make sure UIUtilities is initialized
	    int x = UIUtilities.fontSizeHTML;

	    // make sure log4j is initialized
	    if (System.getProperty("log4j.configuration")==null) {
	        PropertyConfigurator.configure(DEFAULT_LOG4J_CONF);
	    }
	    LogUtil.beginSession(new Integer((int)(Math.random()*100))); // pick a random session number

	    WindowManager.doStartUp();
	    BasicWindow newWindow = WindowManager.openWindow(WindowManager.WINTYPE_LOCAL_TIMELINE, WindowManager.WINLOCATION_CASCADE_DOWN);
	    TimelineFrame newTimelineWindow = (TimelineFrame)newWindow;
	    newTimelineWindow.setTitle("New Timeline");
	    newTimelineWindow.launchWizard();
	}

}
